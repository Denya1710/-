﻿Console.Clear();
    Console.WriteLine("Запуск консольки...");
    Console.WriteLine("");
    Console.WriteLine("Готов к работе!");
            Console.Write("Введите число: ");
        int num = Console.ReadLine();
        if(num % 2)
        {
            Console.WriteLine("Четное!");
        }
        else 
        {
            Console.WriteLine("не четное!");
        }  // Не получилось :( не мог приобразовать string в int!   <------------------------------
