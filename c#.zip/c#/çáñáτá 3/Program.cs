﻿Console.Clear();
Console.WriteLine("Подготовка к работе!");
Console.WriteLine("");
// int number = Console.ReadLine();  Не удается неявно преобразовать тип "string" в "int
int number = 12;
int one = 0;
Console.Write("Выбрано число: ");
Console.WriteLine(number);
while(number > one)
{
    one++;
    one++;
    Console.WriteLine(one);
}
